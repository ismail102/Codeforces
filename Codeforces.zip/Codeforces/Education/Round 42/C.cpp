///    Author: Ismail Hossain(Mukul)
///    Univarsity: Chittagong University of Engineering Annd Technology(Bangladesh)
///    Uva:ISMAIL_HOSSAIN
///    Codeforces: ISMAIL_HOSSAIN
///    SPOJ:ismail_102
///    HackerRank: ismail_102
///    csacademy: ISMAIL_HOSSAIN
///    Facebook: Smily Mukul
 
//BISMILLAHIR RAHMANIR RAHIM
#include<bits/stdc++.h>
#define sf              scanf
#define pf              print
#define dd              double
#define fr              first
#define sc              second
#define pb              push_back
#define MP              make_pair
#define ll              long long
#define PI              acos(-1.0)
#define vci             vector<ll>
#define pll             pair<ll, ll>
#define vcc             vector<char>
#define sz(a)           (a.size())
#define pii             pair<int, int>
#define vcs             vector<string>
#define read(a)         scanf("%d",&a)
#define readI1(a)       scanf("%I64d",&a)
#define read2(a,b)      scanf("%d%d",&a,&b)
#define FOR(i, s, e)    for(ll i=s; i<e; i++)
#define read3(a,b,c)    scanf("%d%d%d",&a,&b,&c)
#define readI2(a,b)     scanf("%I64d %I64d",&a,&b)
#define mem(a, b)       memset(ara, value, sizeof(ara))
#define readI3(a,b,C)   scanf("%I64d %I64d %I64d",&a,&b,&c)
#define open()          freopen("input.txt", "r", stdin)
#define show()          freopen("output.txt", "w", stdout)
#define one(a)          __biltin_popcount(a)
#define Max 2000+5
#define inf INFINITY
#define ull unsigned ll
using namespace std;
const ull Mod = 1000000007;
ll ara[100005*2];
string str;
int dp[12][10005];
int ln;
int binnary(int N)
{
    string s="";
    while(N!=0){
        int r = N%2;
        N/=2;
        s+=r + '0'; 
    }
    //cout<<ln<<' '<<s<<endl;
    int temp = ln - s.size();
    //cout<<temp<<endl;
    for(int i=0;i<temp;i++){
        s=s+'0';
    }
    //cout<<s<<endl;
    reverse(s.begin(),s.end());
    //cout<<s<<endl;
    int ans=0,cnt=0;
    for(int i=0;i<ln;i++){
        if(s[i]=='1'){
            ans = ans*10 + (str[i] - '0');
            cnt++;
        }
    }

    int tt =  sqrt(ans);
    int res=0;
    cnt  = log10(ans) + 1;

   // cout<<ans<<' '<<s<<endl;
    if(tt*tt==ans){
        res=max(res,cnt);
    }
     //cout<<res<<endl;
    return res;

}

int main()
{
    while(cin>>str)
    {
        ln = str.size();
        int ans=0;
        for(int i=1;i<pow(2,ln);i++){
            ans = max(ans,binnary(i));
        }
        if(ans!=0) cout<<ln-ans<<endl;
        else cout<<-1<<endl;
    }
    return 0;
}
