#include<bits/stdc++.h>
#define Max 1005
#define pii pair<int,int>
#define ll long long
#define pb push_back
using namespace std;
int ara[Max];
map<pii,int>vis;
struct st{
    int s;
    pii idx;
}temp[Max];


bool cmp(st a,st b)
{
    return a.s<b.s;
}

int main()
{
    int n,m;

    while(cin>>n)
    {
        vis.clear();
        int mp[Max],aa[Max];
        memset(mp,0,sizeof(mp));
        set<int>st;


        int c=0;
        for(int i=0;i<2*n;i++){
            cin>>aa[i];
            mp[aa[i]]++;
        }
        int ans=0;
        //for(int i=0;i<c-2;i++) cout<<aa[i]<<' ';
        //cout<<endl;


        map<int,pii>tt;

        int cnt=0;
        for(int i=0;i<2*n;i++){

            for(int j=0;j<2*n;j++){
                if(i!=j and (!vis[pii(i,j)] or !vis[pii(j,i)])){
                    vis[pii(i,j)]=true;vis[pii(j,i)]=true;
                    temp[cnt++].s = abs(aa[i] - aa[j]);
                    temp[cnt++].idx=pii(i,j);
                }
            }
            
         }
         sort(temp,temp+cnt,cmp);
         /*for(int i=0;i<cnt;i++){
             cout<<temp[i].idx.first<<endl;
         }*/

         int cc=0;
         for(int i=0;i<cnt;i++){
             //cout<<temp[i].s<<endl;

             if(mp[aa[temp[i].idx.first]]>0 and mp[aa[temp[i].idx.second]]>0){
                 mp[aa[temp[i].idx.first]]--; mp[aa[temp[i].idx.second]]--;
                 ans+=temp[i].s;
                 cc+=2;
                 if(cc+2==2*n) break;
             }

         }

        
         cout<<ans<<endl;

        }
    return 0;
}