#include<bits/stdc++.h>
#define Max 100005
#define pii pair<int,int>
#define ll long long
#define pb push_back
using namespace std;
int ara[Max];
int main()
{
    int n,m;

    string str;
    while(cin>>str)
    {
        string s="",a,b;
        int x=str.size()-1;
        while(str[x]=='0'){

            x--;
        }
        for(int i=0;i<=x;i++) s+=str[i];
        //cout<<s<<endl;
        a=s;
        reverse(s.begin(),s.end());
        //cout<<s<<endl;

        if(a==s) cout<<"YES\n";
        else cout<<"NO\n";
    }


    return 0;
}