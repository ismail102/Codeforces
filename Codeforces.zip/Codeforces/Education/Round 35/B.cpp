#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];

int ara[100005];
int main()
{
    //#ifdef
        
        //freopen("input.txt","r",stdin);
        //freopen("output.txt","w",stdout);
   // #endif
    int n;
    string s,ss;
    int a,b;
    int ans = -1;
    while(cin>>n>>a>>b)
    {
        int c,d;
        ans=-1;
        for(int i=1;i<=n;i++){
            c = a/i;
            int temp = n-i;
            if(temp!=0) d = b/(n-i);
            ans = max(ans,min(c,d));  
        }
       cout<<ans<<endl;

    }
    return  0;
}
