#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];
int main()
{
    int n,a,b;

    //freopen("input.txt","r",stdin);

    while(cin>>n>>a>>b){
       bool f=true;
        for(int i=1;i<=3;i++){
            for(int j=1;j<=3;j++){
                for(int k=1;k<=3;k++){
                    set<int>st;
                    set<int>:: iterator it;
                    st.insert(i);
                    st.insert(j);
                    st.insert(k);

                    //cout<<"i = "<<i<<' '<<" j= "<<j<<' '<<" k= "<<k<<endl;
                    for(int l = 1;l<=500;l++){
                        int c = i+n*l;
                        int d = j+a*l;
                        int e = k+b*l;
                        st.insert(c);
                        st.insert(d);
                        st.insert(e);
                    }
                    int l = 1;
                    f=false;
                    int cnt=0;
                    for(it=st.begin();it!=st.end();it++){
                        //cout<<*it<<' ';
                        if(*it==l){
                            cnt++;
                        }
                        l++;
                    }
                    //cout<<endl;
                    if(cnt>=500){f=true;break;}
                }
                if(f==true) break;
            }
                if(f==true) break;
        }

                if(f==true) puts("YES");
                else puts("NO");
    }
    return  0;
}