
#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];

int ara[100005];
int main()
{
    //#ifdef
        //freopen("input.txt","r",stdin);
        //freopen("output.txt","w",stdout);
   // #endif
    int n;
    string s,ss;
    while(cin>>n)
    {
        vector<int>vc;
        int x;
        int mn=1000000007;
        int id=-1;
        for(int i=0;i<n;i++){
                cin>>ara[i];
                if(mn>ara[i]){
                    mn=ara[i];

                }
        }
        int ans=1000000007;
        //cout<<mn<<endl;
        for(int i=0;i<n;i++){
            if(mn==ara[i]){
                vc.push_back(i);
            }
        }
        for(int i=1;i<vc.size();i++){
            ans= min(vc[i] - vc[i-1],ans);
        }
        cout<<ans<<endl;;

    }
    return  0;
}
