#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,N;
    while(cin>>n)
    {
        N=n;
        int r,cnt=0;
        while(n!=0){
            r = n%10;
            n/=10;
            ++cnt;
        }
       // cout<<r+1<<endl;
        int sum=0;
        sum=sum*10 + (r+1);
        for(int i=1;i<cnt;i++){
            sum=sum*10 + 0;
        }
        cout<<sum-N<<endl;
    }
}
