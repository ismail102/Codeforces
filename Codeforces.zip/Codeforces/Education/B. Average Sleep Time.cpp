#include<bits/stdc++.h>
using namespace std;
#define ll long long

double dp[100000+5];
int main()
{
    ll N;
    double sum=0.0;
    int n;
    int k;
    while(cin>>n>>k)
    {
        memset(dp,0,sizeof(dp));
        int cnt=0;
        sum=0;
        dp[-1]=0.0;
        double x,ans=0.0,ara[n+5];
          for(int i=0;i<n;i++){
            cin>>ara[i];
            dp[i] = dp[i-1]+ara[i];
          }
          int j=0;
          for(int i=0;i<n;i++){

            ans+=(dp[i+n-k+1] - dp[i-1]);
            ans/=k;
          }


      cout<<ans<<endl;
    }
}

