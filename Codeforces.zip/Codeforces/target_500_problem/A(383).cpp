#include<bits/stdc++.h>
#define ll long long
using namespace std;
int ara[105];
bool vis[105];
ll dis[105];

bool BFS(int s){

    memset(vis,false,sizeof(vis));
    memset(dis,0,sizeof(dis));
    queue<int>Q;
    Q.push(s);
    dis[s]=0;
    while(!Q.empty()){

        int u = Q.front();
        Q.pop();
        int v = ara[u];
      // cout<<u<<"==>"<<v<<endl;
        
        if(!vis[v]){
            vis[v]=true;
            Q.push(v);
            dis[v]=dis[u]+1;
        }
        if(v==s){
           /// cout<<v<<endl;
            return true;
            
        }
    }
    return false;

}


int main()
{
    int n;
    while(cin>>n)
    {
        for(int i=1;i<=n;i++) cin>>ara[i];
        ll x,mx=-1,cnt=0,f=0,ans=1;
        for(int i=1;i<=n;i++){

            if(BFS(i)==true){
               //cnt++;
               //cout<<cnt<<endl;
                //cout<<dis[ara[i]]<<endl;
                if(dis[i]==2) x=1;
                else x=dis[i];
                ans=ans*x/__gcd(ans,x);
            }
            else{
                cout<<-1<<endl;f=1;break;
            }
            //cout<<endl;
        }

        if(f!=1){
            ll t = (ans%2)?ans:ans/2;
            cout<<t<<endl;
        }
        
    }
    return 0;
}
