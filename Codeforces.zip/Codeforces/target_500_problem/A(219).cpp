#include<bits/stdc++.h>
using namespace std;
int ara[500005];
bool vis[500005];
int main()
{
    int n;
    while(cin>>n)
    {
        map<int,int>cnt;
        memset(vis,false,sizeof(vis));
        int c=0;
        for(int i=0;i<n;i++){
            cin>>ara[i];
        }
        sort(ara,ara+n);

        int i = n-1;
        int j=n/2-1;
        for(;j>=0;){
            if(ara[i]>=ara[j]*2){
                c++;
                j--;i--;
            }
        }
        
        cout<<n-c<<endl;
    }
    return 0;
}
