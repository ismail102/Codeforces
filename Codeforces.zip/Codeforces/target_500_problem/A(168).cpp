#include<bits/stdc++.h>
using namespace std;
#define ll long long
int ara[100005];
map<ll,bool>vis;
int main()
{
    ll n,m,k;
    while(cin>>n>>k)
    {
        vis.clear();
        for(int i=0;i<n;i++) cin>>ara[i];

        sort(ara,ara+n);
        int cnt=0;
        for(int i=0;i<n;i++){

            if(!vis[ara[i]]){
                vis[ara[i]*k]=true;
               // cout<<ara[i]<<' ';
                cnt++;
            }
            
        }
        cout<<cnt<<endl;

        
        
    }
    return 0;
}
