#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    ll n,m;
    while(cin>>n>>m)
    {
        ll N=1;

        while(1){

            ll a = 2 + (N-1)*2;
            ll b = N*N;

            if(n-b==0){
                cout<<"Valera"<<endl;
                break;
            }
            if(m-a==0){
                cout<<"Vladik"<<endl;
                break;
            }
            
            N++;
        }
    }
}