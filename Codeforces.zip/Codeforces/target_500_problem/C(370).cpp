#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll ara[10];
int main()
{
    ll n,m;

    while(cin>>n>>m){

        ll sum = m*3;
        ara[0]=m;
        ara[1]=m;
        ara[2]=m;
        int cnt=0;
        while(sum<3*n){

            sort(ara,ara+3);
            ll temp = ara[2]+ara[1];
            temp--;
            if(temp<n) ara[0]=temp;
            else ara[0] = n;
            sum = ara[0]+ara[1]+ara[2];
           // cout<<sum<<endl;
           // cout<<ara[0]<<' '<<ara[1]<<' '<<ara[2]<<endl;
           cnt++;

        }
        cout<<cnt<<endl;

    }
    return 0;
}