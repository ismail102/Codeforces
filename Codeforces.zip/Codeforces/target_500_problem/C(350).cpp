#include<bits/stdc++.h>
using namespace std;
int audio[2*100005],sub[2*100005];
int ara[2*100005];

map<int,bool>vis;
map<int,int>cnt;

int main()
{
    
    string str,st;
    int n,m;
    while(cin>>n){
        cnt.clear();
         vis.clear();


       for(int i=0;i<n;i++){
           cin>>ara[i];
           cnt[ara[i]]++;
       }

       cin>>m;

       for(int i=0;i<m;i++) cin>>audio[i];
       for(int i=0;i<m;i++) cin>>sub[i];

       int mx=-1,mxx=-1,idx=0;

       for(int i=0;i<m;i++){

           if(mx<cnt[audio[i]]){
               mx = cnt[audio[i]];
               mxx = cnt[sub[i]];
               idx = i;

           }
           else if(mx==cnt[audio[i]]){
               if(mxx<cnt[sub[i]]){
                   mxx = cnt[sub[i]];
                   idx = i;
               }
           }
       }

       cout<<idx+1<<endl;
    }

    return 0;
}