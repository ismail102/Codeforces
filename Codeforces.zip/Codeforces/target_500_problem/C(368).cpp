#include<bits/stdc++.h>
using namespace std;
#define ll long long
int ara[500005];
bool vis[500005];
int main()
{
    ll n,m,k;
    while(cin>>n)
    {
        if(n%2){
            m = (n*n - 1)/2;
            k = m+1;
        }
        else{
            m = (n*n)/4 - 1;
            k = m + 2;
        }
        if(n==1 or m<=0 or k<=0) cout<<-1<<endl;
        else cout<<m<<' '<<k<<endl;
        
    }
    return 0;
}
