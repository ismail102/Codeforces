#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define Max 100005;
int ara[10000];
int main()
{

    string str;
    int n,m;
    while(cin>>n>>m>>str){
        int len = str.size();
        string st;
        if(len-m>m-1){
            for(int i=0,j=len-1;i<len/2;i++,j--){
                
                if(str[i]!=str[j]){

                    

                }
                

            }
        }
        else{
            for(int i=len-1;i>=len/2;i--) st+=str[i];
        }
        cout<<st<<endl;



    }


    return 0;
}