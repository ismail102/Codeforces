#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pil pair<int,ll>
#define inf 1000000009
int ara[100005];
ll dis[100005];
ll prnt[100005];

vector<pil>edge[100005];

void BFS(int s,int d)
{
    for(int i=0;i<=d;i++) dis[i]=10000000000009;
    
    priority_queue<pil>Q;

    Q.push(pil(s,0));
    dis[s]=0;
    while(!Q.empty()){

        int u = Q.top().first;
        Q.pop();
       // cout<<u<<road[u].size()<<endl;
        for(int i=0;i<edge[u].size();i++){
            int  v = edge[u][i].first;

            ll vcost = edge[u][i].second + dis[u]; 

            //cout<<bus[v]<<' '<<bus[u]<<endl;
            if(dis[v]>vcost){
                dis[v]=vcost;
                prnt[v]=u;
               // cout<<u<<' '<<v<<endl;
                Q.push(pil(v,-dis[v]));
            }
        }
    }


    
    int x=d;
    int i=0;
    if(dis[d]==10000000000009){
        cout<<-1<<endl;
        return;
    }
      while(true)
      {
        ara[i++]=x;
        if(x==s) break;
        x=prnt[x];

      }

      for(int j=i-1;j>=0;j--) cout<<ara[j]<<' ';
      cout<<endl;
}
int main()
{
    string str;
    int n,m,k;
    while(cin>>n>>m)
    {


        for(int i=0;i<=n;i++){
            edge[i].clear();
        }

        int u,v,w;
        for(int i=0;i<m;i++){
            cin>>u>>v>>w;
            edge[u].push_back(pil(v,w));
            edge[v].push_back(pil(u,w));
        }
         BFS(1,n);

    }
    return 0;
}

