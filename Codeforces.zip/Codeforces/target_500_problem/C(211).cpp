#include<bits/stdc++.h>
using namespace std;
#define ll long long
int ara[500005];
bool vis[500005];
int main()
{
    string str;
    ll n,m,k;
    while(cin>>str)
    {
        map<int,int>mp;
        vector<char>st;

        int len=str.size();
        int t=2;
        for(int i=0;i<len;i++){
            
            int j=1;
            char ch=str[i];
            while(j<=t and ch==str[i] and i<len){
            
                    cout<<str[i];
                    i++;j++;
               
            }
            if(j==3) t=1;
            else t=2;

            while(i<len){ if(ch==str[i]) i++;else break;}
            i--;
        }
        cout<<endl;
       
        
    }
    return 0;
}