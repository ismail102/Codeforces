#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    int n,m;
    while(cin>>n>>m)
    {
        int a;
        int ara[10005];
        vector<int>vc,temp;

        for(int i=0;i<n;i++){
            cin>>a;
            vc.push_back(a);
            ara[a]=i;
        }
        int l,r,x;
        for(int i=0;i<m;i++){
            cin>>l>>r>>x;
            int cnt=0;
            for(int j=l-1;j<r;j++){
                if(vc[j]<x) cnt++;
            }

            cout<<cnt<<' '<<ara[x]<<endl;
        }

    }
}