#include<bits/stdc++.h>
using namespace std;
int main()
{
    string str,st;
    int n,m;
    while(cin>>n>>m){
        str="",st="";
        int l = n-1;
        int r = 2*n + 2;
        //if(m<l and m>r) cout<<-1<<endl;
        if(m>=l and m<=r){
            for(int i=0;i<n;i++){
                str+='0';
                if(n-1!=i){
                    str+='1';
                    m--;
                }
            }
           // cout<<str<<endl;
           
            vector<char>ch;

            if(m>1){
                
                ch.push_back('1');
                ch.push_back('1');
                m-=2;
            }
            else if(m>0){

                ch.push_back('1');
                m--;
            }

            for(int i=0;i<str.size();i++){

               ch.push_back(str[i]);
                
                if(m>0 and i%2){m--; ch.push_back('1');}
            }
            if(m>1){
                
                ch.push_back('1');
                ch.push_back('1');
            }
            else if(m>0){

                ch.push_back('1');
            }

            for(int i=0;i<ch.size();i++) cout<<ch[i];
            cout<<endl;

        }
        else cout<<-1<<endl;

    }

    return 0;
}