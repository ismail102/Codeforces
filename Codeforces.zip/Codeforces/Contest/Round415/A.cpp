#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    while(cin>>n)
    {
        int t=n%10;

        if(t==0) cout<<n<<endl;
        else{

            if(abs(t-0)<abs(t-10)) cout<<n-t<<endl;
            else cout<<n+abs(t-10)<<endl;
        }
    }
    return 0;
}
