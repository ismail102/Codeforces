#include<bits/stdc++.h>
using namespace std;
int ara[200005];
struct st{
int v,m;
}s[2*100001];
bool cmp(st a, st b)
{

    if(a.m<b.m) return true;
    return false;
}
int main()
{
    int n;
  scanf("%d",&n);

        int sq=0,nsq=0;
        for(int i=0;i<n;i++){
            cin>>ara[i];
            int temp = sqrt(ara[i]);
            if(temp*temp==ara[i]) sq++;
            else nsq++;

            temp = min((ara[i]-temp*temp) , ((temp+1)*(temp+1) - ara[i]));
            s[i].v = ara[i];
            if(temp==0 and ara[i]==0) s[i].m=2;
            else if(temp==0 and ara[i]!=0) s[i].m = 1;
            else s[i].m = temp;
        }
        sort(s,s+n,cmp);
       long long ans=0;
        for(int i=0;i<n;i++){
           // cout<<s[i].v<<' '<<s[i].m<<endl;
           int temp = sqrt(s[i].v);
            if(sq<nsq){

                if(temp*temp!=s[i].v){
                    ans+=(long long)s[i].m;
                    sq++;
                    nsq--;
                }
            }
            else if(nsq<sq){
                if(temp*temp==s[i].v){
                    ans+=(long long)s[i].m;
                    nsq++;
                    sq--;
                }
            }
            //cout<<sq<<' '<<nsq<<endl;
        }
       cout<<ans<<endl;
    return 0;
}
