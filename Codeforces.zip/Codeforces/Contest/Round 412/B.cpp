#include<bits/stdc++.h>
using namespace std;
#define Max 10000000
#define eps 0.0000001
#define ll long long
bool check(ll n,int p)
{
    ll i = (n/50)%475;
    for(int j=0;j<25;j++){
        i = (i*96 + 42)%475;
        if(i+26==p) return true;
    }
    return false;

}
int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    int n,m;
    ll p,x,y;
    while(cin>>p>>x>>y)
    {
        /*int t = (x/50)%475;
        /*for(int i=1;i<=25;i++){
            cout<<"befor = "<<t<<endl;
            t = (t*96 + 42)%475;
            cout<<"after = "<<t<<' '<<26+t<<' ';
        }
        if(x<y) swap(x,y);
        int temp = p - 26;
        int i=1,b;
        while(true)
        {
            int a = i*475 + temp;
            int c;
            c = a - 42;
            b = c/96;
            if(b*96 + 42==a){
                //cout<<b<<endl;
                break;
            }
            i++;
             
        }
        cout<<b<<endl;

        b = b*50;
        if(b<=x){
            cout<<0<<endl;
            continue;
        }
        int cnt=0;
        while(true)
        {
            if(x<b) cnt++;
            else if(x>=b){
                break;
            }
            x+=100;
        }
        cout<<cnt<<endl;

        cout<<endl;
    }*/
    if(x>=y){
    ll z = x;
    //cout<<z<<' '<<y<<endl;
    bool f=false;
      while(z>=y){
        //cout<<z<<' '<<endl;
        if(!check(z,p)){
            z-=50;
        }
        else{
            f=true;
            break;
        }
      }
      if(f==true){
          cout<<0<<endl;
          continue;
      }

    }

    if(x<y) swap(x,y);
    ll cnt=0;
    for(int i=1;i<=Max;i++){


        if(check(x,p)){
            if(!(i%2)) cnt++;
            cout<<cnt<<endl;
            break;
        }
        else{

            if(!(i%2)){
                cnt++;
            }
            x += 50;
        }
    }
    }

    return 0;
}