#include<bits/stdc++.h>
using namespace std;
#define Max 10005
#define eps 0.0000001
int A[Max],B[Max];
int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    int n,m;
    while(cin>>n)
    {
        for(int i=0;i<n;i++) cin>>A[i]>>B[i];
        bool rate = false;
        for(int i=0;i<n;i++){
            if(A[i]!=B[i]){
                rate=true;
                break;
            }
        }
        if(rate==true){
            puts("rated");
        }
        else{
            bool f=false;
            for(int i=1;i<n;i++){
                if(A[i]<=A[i-1]) continue;
                else{f=true;break;}
            }
            if(f) puts("unrated");
            else puts("maybe");
        }
    }
    

    return 0;
}