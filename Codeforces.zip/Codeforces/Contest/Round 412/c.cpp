#include<bits/stdc++.h>
using namespace std;
#define Max 1000000000
#define eps 0.0000001
#define ll long long
int main()
{

    //freopen("input.txt","r",stdin);
    ll x,y,p,q;
    while(cin>>x>>y>>p>>q)
    {
        ll low=0;
        ll high = Max;
        ll mid=-1;
        while(low<=high)
        {
            ll a = x*q;
            ll b = y*p;
            mid = (low+high)/2;
            //cout<<mid<<endl;
            ll c =y+mid;
            ll d =c/q;
            //cout<<x*q<<' '<<y*p<<endl;
            if(d*q<=c*p) high=mid-1;
            else low=mid+1;
        }
        cout<<mid<<endl;
    }
}