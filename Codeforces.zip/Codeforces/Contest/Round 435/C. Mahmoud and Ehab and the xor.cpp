#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,x;
    while(cin>>n>>x)
    {
        int xorsum = 0;

        if(n==2 and x==0){
            puts("NO");
            continue;
        }
        puts("YES");
        if(n==1){
            printf("%d\n",x);
        }
        else if(n==2 and x>0){
            printf("%d %d\n",0,x);
        }
        else{
            for(int i=1;i<=n-3;i++){
                printf("%d ",i);
                xorsum^=i;
            }
            if(xorsum==x){
                printf("%d %d %d\n",(1<<17),(1<<18),(1<<17)^(1<<18));
            }
            else{
                printf("%d %d %d\n",0,(1<<17),(1<<17)^x^xorsum);
            }
        }


    }
   return 0;
}
