#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define pi acos(-1)
#define Max 100000 + 5
using namespace std;
vector<int>vc[Max],ans[5];
int ara[Max];
bool vis[Max];

void dfs(int u,int L)
{
    vis[u]=true;

    ara[u]=L;

    ans[L].pb(u);

    for(int i=0;i<vc[u].size();i++){
        if(vis[vc[u][i]]==false){
           dfs(vc[u][i],ara[u]%2==0?1:2);
        }
    }
}


int main()
{
    int n;
    while(cin>>n)
    {
        int u,v;

        for(int i=0;i<=Max;i++){
                ara[i]=0;
                vis[i]=false;
                vc[i].clear();

        }
        ans[1].clear();
        ans[2].clear();
        for(int i=0;i<n-1;i++){
            cin>>u>>v;
            vc[u].pb(v);
            vc[v].pb(u);
        }

        for(int i=1;i<=n;i++){

            if(vis[i]!=true)
            {
                vis[i]=true;
                dfs(i,1);
            }
        }

        //cout<<vc[1].size()<<endl;
       // cout<<vc[2].size()<<endl;

        ll x = ans[1].size();
        ll y = ans[2].size();

        //cout<<x<<' '<<y<<endl;

        cout<<x*y - (ll)n + (ll)1<<endl;
    }


return 0;
}

