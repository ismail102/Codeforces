#include<bits/stdc++.h>
using namespace std;
int main()
{
    int x,y,z;
    x = 1<<17;
    y = 1<<18;
}
