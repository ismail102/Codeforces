#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define pi acos(-1)
#define Max 100000 + 5
using namespace std;
int main()
{
    int n,x;
    while(cin>>n>>x)
    {
        int ara[n+5];
        for(int i=0;i<n;i++){
            cin>>ara[i];
        }

        sort(ara,ara+n);
        int cnt=0;
        bool f=false;
        for(int i=0;i<n;i++){
            if(ara[i]<x) cnt++;
            if(ara[i]==x){
                f=true;
            }
        }

        int t = x;
        if(f==false){
            cout<<t-cnt<<endl;
        }
        else cout<<t-cnt+1<<endl;

    }

return 0;
}
