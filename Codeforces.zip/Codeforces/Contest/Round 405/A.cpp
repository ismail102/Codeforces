#include<bits/stdc++.h>
using namespace std;
int main()
{
    //freopen("input.txt","r",stdin);
    double L,H,W;
    int n,m;
    while(cin>>n>>m){
        int cnt=0;
        if(n==1 and m==1){
            cout<<1<<endl;
            continue;
        }
        while(1){
            cnt++;
            if(n>m)break;
            n=3*n;
            m=2*m;
        }
        cout<<cnt-1<<endl;
    }
    return 0;
}