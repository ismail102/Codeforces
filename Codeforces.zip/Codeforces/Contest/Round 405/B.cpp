#include<bits/stdc++.h>
using namespace std;
#define Max 150002
#define ll long long
bool vis[Max];
ll cnt[Max];
vector<int>edge[Max];
ll nd,ed;
void dfs(int u)
{
    vis[u]=true;
    for(int i=0;i<edge[u].size();i++){

        int v = edge[u][i];

        if(!vis[v]){
            nd++;

            ed+=cnt[v];

            dfs(v);
             
        }
    }
    
}
int main()
{
    freopen("input.txt","r",stdin);
    double L,H,W;
    int n,m;
    while(cin>>n>>m){
        nd=0,ed=0;

        memset(cnt,0,sizeof(cnt));

        for(int i=0;i<=n;i++) edge[i].clear();

        int u,v;

        for(int i=0;i<m;i++){
            cin>>u>>v;
            edge[u].push_back(v);
            edge[v].push_back(u);
            cnt[u]++;
            cnt[v]++;
        }

        memset(vis,false,sizeof(vis));

        bool f=false;
        for(int i=1;i<=n;i++){
            if(!vis[i]){
                nd=1;
                ed=0;
                ed += cnt[i];
                dfs(i);
                //cout<<ed<<' '<<nd*(nd-1)<<endl;
                if(ed==(nd*(nd-1))) f = true;
                else{f=0;break;}
            }
        }
        if(f){
            cout<<"YES"<<endl;
        }
        else cout<<"NO"<<endl;
    }
    return 0;
}