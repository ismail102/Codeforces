#include<bits/stdc++.h>
using namespace std;
#define Max 150002
bool vis[Max];
int cnt[Max];
vector<int>edge[Max];
int nd,ed;
int main()
{
    //freopen("input.txt","r",stdin);
    string str[100];
    char j='A',k;
    for(int i=1;i<=26;i++,j++) str[i] = j;

    j='a',k='A';
    for(int i=27;i<=52;i++,j++,k++) {
        str[i]=k;
        str[i]+=j;
    }
    double L,H,W;
    int n,m;
    while(cin>>n>>m){
        string st;
        vector<string>ans;
        int k=1;
        for(int i=0;i<n-m+1;i++){
            cin>>st;
            if(i==0){
                if(st=="YES"){
                    for(int j=i;j<i+m;j++){
                        ans.push_back(str[k++]);
                    }
                }

                else{

                    for(int j=i;j<i+m-1;j++){
                        ans.push_back(str[k++]);
                    }
                    ans.push_back(str[1]);
                }

            }
            else{

                  if(st=="YES"){
                      ans.push_back(str[k++]);
                  }

                  else{

                      string ss = ans[i];
                      ans.push_back(ss);
                  }

            }
        }

        for(int i=0;i<ans.size();i++) cout<<ans[i]<<' ';
        cout<<endl;

    }
    return 0;
}