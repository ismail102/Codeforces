#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];
int dx[]={1,0,-1,0};
int dy[]={0,-1,0,+1};
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
    #endif
    int n;
    double r;
    while(cin>>n>>r)
    {
        double ans=0.0;
        ans+=(double)r;
        double x[n+5],y[n+5];
        y[0]=(double)r;
        for(int i=0;i<n;i++){
            cin>>x[i];
        }

        for(int i=1;i<n;i++){
            y[i]=r;
            if(x[i]==x[i-1]){
                y[i] = y[i-1] + 2*r;continue;
            }
            for(int j=i-1;j>=0;j--){
                //cout<<"x = "<<x[j]<<' '<<x[i]<<endl;
                //cout<<x[j]+r<<' '<<x[i]-r<<" or "<<x[j]-r<<' '<<x[i]+r<<endl;
                if(((x[j]+r) >= (x[i] - r) and x[i]>x[j]) or ((x[j]-r)<=(x[i]+r) and x[i]<x[j]) ){
                     
                    double c = (x[j] - x[i])*(x[j] - x[i]) + (y[j]*y[j]) - (2.0*r)*(2.0*r);

                    double b = 2.0*y[j];

                    double sq = sqrt((b*b) - (4*c));
                    //cout<<c<<' '<<sq<<endl;

                    double e = (b + sq);
                    e/=2.0;
                   
                    y[i]=e;
                    cout<<e<<endl;
                    break;
                }
            }

        }
       for(int i=0;i<n;i++){
        printf("%.8lf ",y[i]);
       }
    }
    return 0;
    
}