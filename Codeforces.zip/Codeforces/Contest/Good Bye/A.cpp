  //বিসমিল্লাহির রাহমানির রাহিম
 // ইসমাইল হোসাইন (মুকুল)

#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];
int main()
{
    int n,m;
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
    #endif  
    string str;
    while(cin>>str){

        int cnt=0;
        for(int i=0;i<str.size();i++){
            if(str[i]=='a' or str[i]=='e' or str[i]=='i' or str[i]=='o' or str[i]=='u' or (str[i]-'0')%2==1 and str[i]>='0' and str[i]<='9') {
                //cout<<str[i]<<endl;
                cnt++;
            }
        }
        cout<<cnt<<endl;
    }


    return 0;
}