#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define pii pair<int,int>
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];
int dx[]={1,0,-1,0};
int dy[]={0,-1,0,+1};
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
    #endif  
    int n,m;
    while(cin>>n>>m){
        string str[n+5];
        int sx,sy,ex,ey;
        for(int i=0;i<n;i++){
            cin>>str[i];

            for(int j=0;j<m;j++){

                if(str[i][j]=='S'){
                    sx=i;
                    sy=j;
                }
                else if(str[i][j]=='E'){
                    ex = i;
                    ey = j;
                }
            }
        }
        string st;
        cin>>st;

        int ara[10];
        ara[0]=0;
        ara[1]=1;
        ara[2]=2;
        ara[3]=3;
        int mp[10];
        int cnt=0;
        int ssx = sx,ssy=sy;
     do {

         //cout<<ara[0]<<' '<<ara[1]<<' '<<ara[2]<<' '<<ara[3]<<endl;

        mp[ara[0]]=0;
        mp[ara[1]]=1;
        mp[ara[2]]=2;
        mp[ara[3]]=3;


        sx=ssx,sy=ssy;
        for(int i=0;i<st.size();i++){

            sx = sx + dx[mp[st[i]-'0']];
            sy = sy + dy[mp[st[i]-'0']];
            if(sx<0 or sx>=n or sy<0 or sy>=m) break;
            //if(sx>=0 and sx<n and sy>=0 and sy<m) cout<<sx<<' '<<sy<<' '<<str[sx][sy]<<endl;

            if((sx>=0 and sx<n and sy>=0 and sy<m and sx==ex and sy==ey)){
                cnt++;
                break;
            }
            else if(sx>=0 and sx<n and sy>=0 and sy<m and str[sx][sy]=='#') break;
        }

        } while ( next_permutation(ara,ara+4));
    cout<<cnt<<endl;
    }
return  0;
}