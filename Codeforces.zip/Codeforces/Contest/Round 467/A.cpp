#include<bits/stdc++.h>
using namespace std;

int ara[100+5];
int main()
{
    int n,m;
    while(cin>>n){
        set<int>st;
        for(int i=0;i<n;i++){
            cin>>ara[i];
            if(ara[i]!=0) st.insert(ara[i]);
        }
        cout<<st.size()<<endl;

    }
    return 0;
}
