#include<stdio.h>
// int = integer
int main()
{
    int a,b,sum; //  a,b এখানে পূর্নসংখ্যার মাধ্যম
    scanf("%d%d",&a,&b); // স্ট্যান্ডার্ট ইনপুট
    sum=a-b; // যোগফল  নির্ণয়
    printf("summation = %d",sum); // স্ট্যান্ডার্ট অাউটপুট
}