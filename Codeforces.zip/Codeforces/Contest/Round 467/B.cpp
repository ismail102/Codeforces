#include<bits/stdc++.h>
using namespace std;
bool isprime(int n,int p)
{
    int sq = sqrt(n)+1;
    if(n%2==0) return false;

    for(int i=3;i<=sq and i<=p;i+=2){
        if(n%i==0) return false;
    }
    return  true;
}
int main()
{
    int y,p;
    while(cin>>p>>y)
    {
        bool flag = false;
        for(int i = y;i > p;i--){
            if(isprime(i,p)){
                flag=true;
                cout<<i<<endl;
                break;
            }
        }
        if(!flag) cout<<-1<<endl;
    }
    return 0;
}