#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    while(cin>>n)
    {
        if(n==1){
            cout<<1<<endl;
            continue;
        }

        cout<<n+1<<endl;

        for(int i=1;i<=n+1-3;i++){
            cout<<i<<' ';
        }
        cout<<n<<' '<<n-1<<' '<<n<<endl;
    }
    return 0;
}
