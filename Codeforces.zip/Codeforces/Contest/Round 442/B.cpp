#include<bits/stdc++.h>
using namespace std;
int main()
{
    string str;
    while(cin>>str)
    {
        int i=0;
        while(str[i]!='b' and i<str.size()) i++;

        int j=i+1;
        int l = i;
        while(str[j]!='b' and j<str.size()) j++;
        int r = j;
        int a = 0;
        for(int i=l;i<=r;i++){
            if(str[i]=='a') a++;
        }

        i=0;
        while(str[i]!='a' and i<str.size()) i++;

        j=i+1;
        l = i;
        while(str[j]!='a' and j<str.size()) j++;
        r = j;
        int b = 0;
        //cout<<l<<' '<<r<<endl;
        for(int i=l;i<=r;i++){
            if(str[i]=='b') b++;
        }
        cout<<str.size() - min(a,b)<<endl;
    }
}
