#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];
int main()
{
    int n;
 while(cin>>n)
 {

     bool vis[101][101];
      memset(vis,false,sizeof(vis));
     int cnt=0;
    for(int i=0;i<n;i++){

        for(int j=i+1;j<=n;j++){
            for(int k=n;k>=0;){
               // cout<<i<<"--"<<j<<' '<<j<<"--"<<k<<endl;
                if(vis[i][j]==false and vis[j][k]==false and j<=k){
                    cnt++;

                    vis[i][j]=true;
                    vis[j][k]=true;
                    break;
                }
                else k--;
            }
        }

    }
    cout<<cnt<<endl;
 }
}

