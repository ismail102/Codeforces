#include<bits/stdc++.h>
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define sf(a) scanf("%d",&a)
#define pf(a) printf("%d\n",a)
#define ll long long
#define ull unsigned long long
using namespace std;
#define Max 10000 + 5
string str[100005];


int main()
{
    freopen("output.txt","w",stdin);
    int n;
    string s,ss;
    while(cin>>s>>ss){
        int i=1;
        string ans="";

        ans=ans+s[0];

        while(s[i]<ss[0] and i<s.size()){
            ans+=s[i];
            i++;
        }
        ans+=ss[0];
        cout<<ans<<endl;
    }
}
